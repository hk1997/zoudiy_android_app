package com.example.zoudiy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.zoudiy.R;

public class SignupKids extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupkids);

        Button addkidbutton = findViewById(R.id.addkidbutton);
        addkidbutton.setOnClickListener(v -> {
            Intent intent=new Intent(SignupKids.this, AddNewKid.class);
            startActivity(intent);
        });
    }
}
