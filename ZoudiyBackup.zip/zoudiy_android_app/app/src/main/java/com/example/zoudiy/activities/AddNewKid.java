package com.example.zoudiy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.zoudiy.R;

public class AddNewKid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_kid);
        Button B1= findViewById(R.id.buttonRegister);
        B1.setOnClickListener(v -> {
            Intent intent=new Intent(AddNewKid.this, HomeActivity.class);
            startActivity(intent);
        });

    }
}
