package com.example.zoudiy.Fragment;

import androidx.fragment.app.Fragment;

public class ThirdFragment {
    public static Fragment newInstance(int i) {

        return null;
    }
}
